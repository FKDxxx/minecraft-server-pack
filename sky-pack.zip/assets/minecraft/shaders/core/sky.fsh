#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:globals.glsl>

layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
layout(location = 2) in vec3 skyDir;

layout(location = 0) out vec4 fragColor;

// sky-pack clouds: ported from SoftyClouds 1.2 by Falanta Fantomo (MIT) to the 26.3 shader format
float sc_hash3D(vec3 p) {
    p = fract(p * vec3(123.34, 456.21, 789.13));
    p += dot(p, p + 45.32);
    return fract(p.x * p.y * p.z);
}

float sc_noise3D(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    vec3 u = f * f * (3.0 - 2.0 * f);
    return mix(mix(mix(sc_hash3D(i), sc_hash3D(i + vec3(1, 0, 0)), u.x),
                   mix(sc_hash3D(i + vec3(0, 1, 0)), sc_hash3D(i + vec3(1, 1, 0)), u.x), u.y),
               mix(mix(sc_hash3D(i + vec3(0, 0, 1)), sc_hash3D(i + vec3(1, 0, 1)), u.x),
                   mix(sc_hash3D(i + vec3(0, 1, 1)), sc_hash3D(i + vec3(1, 1, 1)), u.x), u.y), u.z);
}

// fbm with an exact early exit (sky-pack speed-up): returns -1 as soon as even the largest possible remaining
// octaves could not lift the value to "need" - that layer would add nothing, so the picture stays identical
float sc_fbm3D(vec3 p, float need) {
    float value = 0.0;
    float amplitude = 0.5;
    float rest = 1.0 - exp2(-float(5));   // sum of all octave amplitudes
    for (int i = 0; i < 5; i++) {
        value += amplitude * sc_noise3D(p * 0.05);
        rest -= amplitude;
        if (value + rest < need) return -1.0;
        p *= 2.0;
        amplitude *= 0.5;
    }
    return value;
}

float sc_bayer4(vec2 screenPos) {
    vec2 c = mod(floor(screenPos), 4.0);
    const float bayer[16] = float[](0.0, 0.5, 0.125, 0.625, 0.75, 0.25, 0.875, 0.375,
                                    0.1875, 0.6875, 0.0625, 0.5625, 0.9375, 0.4375, 0.8125, 0.3125);
    return bayer[int(c.y) * 4 + int(c.x)];
}

// layered noise clouds over the sky colour skyCol; pos = sky plane vertex position; warm = facing a sunset (0..1)
vec3 softClouds(vec3 pos, vec3 skyCol, float warm) {
    // the player's own Cloud Distance slider at its minimum (2 chunks = 32 blocks) switches these clouds off for them
    if (FogCloudsEnd < 40.0) return skyCol;
    float t = smoothstep(0.15, 0.0, max(ColorModulator.r, max(ColorModulator.g, ColorModulator.b)));   // night
    vec3 base = vec3(((ColorModulator.r + ColorModulator.g + ColorModulator.b) / 3.0) + 0.05 + 0.35 * (1.0 - t));
    base = mix(base, base * vec3(1.15, 0.86, 0.76), warm * 0.6);   // sky-pack: sunset-lit clouds
    // how stormy: where the fog colour sits between a clear and a storm reference (denser clouds in rain)
    vec3 clearRef = mix(vec3(0.753, 0.847, 1.0), vec3(0.043, 0.047, 0.086), t);
    vec3 stormRef = mix(vec3(0.184, 0.208, 0.298), vec3(0.008, 0.008, 0.024), t);
    vec3 target = stormRef - clearRef;
    float storm = dot(target, target) > 0.0001 ? clamp(dot(FogColor.rgb - clearRef, target) / dot(target, target), 0.0, 1.0) : 0.0;

    vec3 col = skyCol;
    float alpha = 0.0;
    float distanceFactor = length(pos.xz * 0.001);
    const int layers = 8;
    const float mosaic = 4.0;
    const float cloudHeight = 2400.0;
    float thickness = 1024.0 * (1.0 - smoothstep(0.2, 0.8, distanceFactor));
    const float threshold = 0.1;
    float jitter = sc_bayer4(gl_FragCoord.xy);
    float energy = 1.5;
    for (int i = layers - 1; i >= 0; i--) {
        if (alpha >= 1.0) break;
        float lh = clamp((float(i) + (jitter - 0.5)) / float(layers - 1), 0.0, 1.0);
        float edge = abs(lh - 0.5) * 2.0;
        edge = edge * edge * (3.0 - 2.0 * edge);
        vec2 coords = pos.xz * 0.1 - pos.xz / cloudHeight * (-1.0 - lh) * thickness + GameTime * 0.04;
        vec2 tiled = floor(coords * mosaic) / mosaic;
        // lowest fbm value that can still show: inverse smoothstep of (threshold + edge * 0.2), minus the storm boost,
        // with a small safety margin so float rounding can never skip a visible layer
        float showAt = 0.3 + 0.5 * (0.5 - sin(asin(1.0 - 2.0 * (threshold + edge * 0.2)) / 3.0)) - storm * 0.25 - 0.002;
        float density = sc_fbm3D(vec3(tiled.x + GameTime * 200.0, lh * 4.0 + GameTime * 200.0, tiled.y + sin(GameTime * 90.0) * 0.1), showAt);
        if (density < 0.0) continue;
        density = smoothstep(0.3, 0.8, clamp(density + storm * 0.25, 0.0, 1.0)) - edge * 0.2;
        if (density > threshold) {
            float a = smoothstep(threshold, threshold + 0.75, density);
            vec3 layerCol = mix(base * 0.5, base, energy * lh);
            energy *= clamp(1.0 - a * 0.25, 0.0, 1.0);
            float visible = smoothstep(0.325, 0.675, a * (1.0 - alpha));
            col = clamp(mix(col, layerCol, visible), 0.0, 1.0);
            alpha += visible * 0.1;
        }
    }
    float steps = 64.0 + 64.0 * t;
    return floor(col * steps) / steps;
}

void main() {
    // sky-pack: real gradient - deep saturated blue overhead, bright hazy band toward the horizon
    vec4 sky = ColorModulator;
    float h = normalize(skyDir).y;
    if (h > 0.0) {
        // facing a sunset/sunrise the horizon fog turns warm: the warm band then climbs higher and a soft
        // rose layer sits between it and the blue top (by day/night warm = 0, so nothing changes)
        float warm = clamp((FogColor.r - FogColor.b) * 2.5, 0.0, 1.0);
        float t = pow(clamp(h, 0.0, 1.0), mix(0.42, 0.75, warm));
        vec3 horizon = mix(sky.rgb, FogColor.rgb, 0.70) * 1.10;
        vec3 zenith = sky.rgb * vec3(0.60, 0.72, 0.95);
        vec3 col = mix(horizon, zenith, t);
        float band = warm * smoothstep(0.0, 0.25, h) * (1.0 - smoothstep(0.25, 0.7, h));
        col = mix(col, col * vec3(1.18, 0.86, 1.12) + vec3(0.03, 0.0, 0.03), band * 0.6);
        sky.rgb = softClouds(skyDir, col, warm);
    }
    fragColor = apply_fog(sky, sphericalVertexDistance, cylindricalVertexDistance, 0.0, FogSkyEnd, FogSkyEnd, FogSkyEnd, FogColor);
}
