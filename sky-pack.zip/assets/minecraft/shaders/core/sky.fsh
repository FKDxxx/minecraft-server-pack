#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>

layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
layout(location = 2) in vec3 skyDir;

layout(location = 0) out vec4 fragColor;

void main() {
    // sky-pack: real gradient - deep saturated blue overhead, bright hazy band toward the horizon
    vec4 sky = ColorModulator;
    float h = normalize(skyDir).y;
    if (h > 0.0) {
        // facing a sunset/sunrise the horizon fog turns warm: the warm band then climbs higher and a soft
        // rose layer sits between it and the blue top (by day/night warm = 0, so nothing changes)
        float warm = clamp((FogColor.r - FogColor.b) * 2.5, 0.0, 1.0);
        float t = pow(clamp(h, 0.0, 1.0), mix(0.42, 0.75, warm));
        vec3 horizon = mix(sky.rgb, FogColor.rgb, 0.70) * 1.10;
        vec3 zenith = sky.rgb * vec3(0.60, 0.72, 0.95);
        vec3 col = mix(horizon, zenith, t);
        float band = warm * smoothstep(0.0, 0.25, h) * (1.0 - smoothstep(0.25, 0.7, h));
        col = mix(col, col * vec3(1.18, 0.86, 1.12) + vec3(0.03, 0.0, 0.03), band * 0.6);
        sky.rgb = col;
    }
    fragColor = apply_fog(sky, sphericalVertexDistance, cylindricalVertexDistance, 0.0, FogSkyEnd, FogSkyEnd, FogSkyEnd, FogColor);
}
