#version 330
#extension GL_ARB_separate_shader_objects : require

layout(std140) uniform LightmapInfo {
    float SkyFactor;
    float BlockFactor;
    float NightVisionFactor;
    float DarknessScale;
    float BossOverlayWorldDarkeningFactor;
    float BrightnessFactor;
    vec3 BlockLightTint;
    vec3 SkyLightColor;
    vec3 AmbientColor;
    vec3 NightVisionColor;
} lightmapInfo;

layout(location = 0) in vec2 texCoord;

layout(location = 0) out vec4 fragColor;

float get_brightness(float level) {
    return level / (4.0 - 3.0 * level);
}

vec3 notGamma(vec3 color) {
    float maxComponent = max(max(color.x, color.y), color.z);
    float maxInverted = 1.0f - maxComponent;
    float maxScaled = 1.0f - maxInverted * maxInverted * maxInverted * maxInverted;
    return color * (maxScaled / maxComponent);
}

float parabolicMixFactor(float level) {
    return (2.0 * level - 1.0) * (2.0 * level - 1.0);
}

void main() {
    // Calculate block and sky brightness levels based on texture coordinates
    float block_level = floor(texCoord.x * 16) / 15;
    float sky_level = floor(texCoord.y * 16) / 15;

    float block_brightness = get_brightness(block_level) * lightmapInfo.BlockFactor;
    float sky_brightness = get_brightness(sky_level) * lightmapInfo.SkyFactor;

    // Calculate ambient color with or without night vision
    vec3 nightVisionColor = lightmapInfo.NightVisionColor * lightmapInfo.NightVisionFactor;
    vec3 color = max(lightmapInfo.AmbientColor, nightVisionColor);

    // Add sky light
    // sky-pack: shadows follow the real light - where the sky is blocked (under trees, roofs, overhangs, cave
    // mouths) the sky light turns cool blue and a bit darker; full sunlight stays as the server sets it.
    // Mobs and players standing in those spots get the same shadow (the lightmap lights everything)
    float skyShadow = 1.0 - smoothstep(0.78, 1.0, sky_level);
    vec3 shadeTint = mix(vec3(1.0), vec3(0.70, 0.80, 1.02), skyShadow);
    color += lightmapInfo.SkyLightColor * shadeTint * sky_brightness;

    // Add block light
    vec3 BlockLightColor = mix(lightmapInfo.BlockLightTint, vec3(1.0), 0.9 * parabolicMixFactor(block_level));
    // sky-pack: torch and lamp light - warm white at the source, deepening to an orange ember glow toward the
    // edge of its reach, and falling off faster so the pool fades into real shadow
    vec3 ember = mix(vec3(1.0, 0.52, 0.22), vec3(1.06, 0.95, 0.80), smoothstep(0.35, 0.95, block_level));
    color += BlockLightColor * ember * pow(block_brightness, 1.3);

    // Apply boss overlay darkening effect
    color = mix(color, color * vec3(0.7, 0.6, 0.6), lightmapInfo.BossOverlayWorldDarkeningFactor);

    // Apply darkness effect scale
    color = color - vec3(lightmapInfo.DarknessScale);

    // Apply brightness
    color = clamp(color, 0.0, 1.0);
    vec3 notGamma = notGamma(color);
    color = mix(color, notGamma, lightmapInfo.BrightnessFactor);

    // sky-pack: contrast - deeper shadows, richer midtones, highlights unchanged
    color = clamp(mix(color, color * color * (3.0 - 2.0 * color), 0.32), 0.0, 1.0);
    fragColor = vec4(color, 1.0);
}
