#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:fog.glsl>
#include <minecraft:globals.glsl>
#include <minecraft:texture_sampling.glsl>
#include <minecraft:oit.glsl>
#include <minecraft:terrainglobals.glsl>
#ifndef MULTIDRAW_TERRAIN
    #include <minecraft:chunksection.glsl>
#endif

uniform sampler2D Sampler0;

layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
layout(location = 2) in vec4 vertexColor;
layout(location = 3) in vec2 texCoord0;
layout(location = 4) in float chunkVisibility;
layout(location = 5) in float waterMask;
layout(location = 6) in vec3 viewPos;

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

vec4 calculateFinalColor(vec4 color) {
    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif
    return apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
}

void main() {
    vec4 color = (UseRgss == 1 ? sampleRGSS(Sampler0, texCoord0, 1.0f / TextureSize) : sampleNearest(Sampler0, texCoord0, 1.0f / TextureSize)) * vertexColor;
    // sky-pack: water surfaces reflect the sky (fresnel), with moving ripples and sparkles
    vec3 geo = normalize(cross(dFdx(viewPos), dFdy(viewPos)));
    if (waterMask > 0.5) {
        vec3 dir = normalize(viewPos);
        float level = smoothstep(0.80, 0.95, abs(geo.y));
        if (dir.y < 0.0 && level > 0.0) {
            vec3 world = viewPos - CameraOffset + vec3(CameraBlockPos);
            float t = GameTime * 1200.0;
            vec2 g = vec2(0.8, 0.6) * cos(dot(world.xz, vec2(0.8, 0.6)) * 2.3 + t * 1.7) * 0.07
                   + vec2(-0.5, 0.86) * cos(dot(world.xz, vec2(-0.5, 0.86)) * 3.9 + t * 2.3) * 0.045
                   + vec2(0.2, -0.98) * cos(dot(world.xz, vec2(0.2, -0.98)) * 7.1 + t * 3.1) * 0.03;
            vec3 n = normalize(vec3(-g.x, 1.0, -g.y));
            vec3 r = reflect(dir, n);
            float up = clamp(r.y, 0.0, 1.0);
            vec3 horizon = FogColor.rgb * 1.08;
            vec3 zenith = FogColor.rgb * vec3(0.52, 0.66, 0.96);
            vec3 skyRefl = mix(horizon, zenith, pow(up, 0.6));
            float cosi = clamp(-dot(dir, n), 0.0, 1.0);
            float fresnel = clamp(0.02 + 0.98 * pow(1.0 - cosi, 5.0), 0.0, 0.85) * level;
            float day = clamp(dot(FogColor.rgb, vec3(0.3, 0.5, 0.2)) * 1.6, 0.0, 1.0);
            float spark = pow(max(0.0, sin(world.x * 4.7 + t * 2.9) * sin(world.z * 5.3 - t * 2.3)), 60.0)
                        * smoothstep(0.55, 0.95, 1.0 - cosi) * day * level;
            #ifndef OIT_ALPHA_ONLY
            color.rgb = mix(color.rgb, skyRefl, fresnel) + spark * 0.18;
            #endif
            color.a = mix(color.a, 1.0, fresnel * 0.6);
        }
    }
    #ifndef OIT_ALPHA_ONLY
    color = mix(FogColor * vec4(1, 1, 1, color.a), color, chunkVisibility);
    #endif
    #ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
    #endif

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = calculateFinalColor(color);
    #endif
}
