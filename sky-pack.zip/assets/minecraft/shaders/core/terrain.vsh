#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:fog.glsl>
#include <minecraft:globals.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:sample_lightmap.glsl>
#include <minecraft:terrainglobals.glsl>
#ifndef MULTIDRAW_TERRAIN
    #include <minecraft:chunksection.glsl>
#endif

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
layout(location = 3) in ivec2 UV2;
#ifdef MULTIDRAW_TERRAIN
layout(location = 4) in ivec3 ChunkPosition;
layout(location = 5) in float ChunkVisibility;
#endif

#ifndef OIT_ALPHA_ONLY
uniform sampler2D Sampler2;
#endif

layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;
layout(location = 4) out float chunkVisibility;
layout(location = 5) out float waterMask;
layout(location = 6) out vec3 viewPos;
layout(location = 7) out vec4 sunLight;
layout(location = 8) out vec2 lightUV;

uniform sampler2D Sampler0;

void main() {
    vec3 pos = Position + (ChunkPosition - CameraBlockPos) + CameraOffset;

    // sky-pack: wind and waves. Marked sprites carry the marker in a ring just outside the art, so check the
    // 4 texels around this vertex's UV point (one of them is art, the others ring)
    vec3 wp = Position + vec3(ChunkPosition);
    float s = GameTime * 1200.0;
    vec2 uvPx = UV0 * vec2(TextureSize);
    float marker = floor(texelFetch(Sampler0, ivec2(uvPx), 0).a * 255.0 + 0.5);
    float leaf = 0.0;
    float hang = 0.0;
    float plantTop = 0.0;
    for (int i = 0; i < 4; i++) {
        vec2 o = vec2((i & 1) == 0 ? -0.5 : 0.5, (i & 2) == 0 ? -0.5 : 0.5);
        float a = floor(texelFetch(Sampler0, ivec2(floor(uvPx + o)), 0).a * 255.0 + 0.5);
        if (a == 253.0) leaf = 1.0;
        if (a == 252.0) hang = 1.0;
        if (a == 251.0) plantTop = 1.0;
    }
    // gusts roll across the land; a fast flutter rides on the slow sway
    float gust = 0.55 + 0.45 * sin(s * 0.31 + wp.x * 0.045 + wp.z * 0.035);
    float flutter = sin(s * 7.3 + wp.x * 2.3 + wp.z * 1.9 + wp.y * 1.7);
    if (leaf > 0.5) {
        pos.x += (sin(s * 1.9 + wp.x * 0.7 + wp.y * 0.4) + 0.5 * sin(s * 3.7 + wp.z * 1.3) + 0.3 * flutter) * 0.13 * gust;
        pos.z += (cos(s * 1.6 + wp.z * 0.7 + wp.y * 0.3) + 0.5 * cos(s * 3.1 + wp.x * 1.1) - 0.3 * flutter) * 0.13 * gust;
        pos.y += (sin(s * 2.6 + wp.x * 0.9 + wp.z * 0.9) + 0.4 * flutter) * 0.05 * gust;
    } else if (hang > 0.5) {
        // vines: the whole sheet lifts and drifts; small sideways part so it never sinks into its wall
        pos.y += (sin(s * 2.1 + wp.x * 0.8 + wp.z * 0.8 + wp.y * 0.5) + 0.3 * flutter) * 0.07 * gust;
        pos.x += sin(s * 1.7 + wp.y * 0.9 + wp.z * 0.6) * 0.03 * gust;
        pos.z += cos(s * 1.5 + wp.y * 0.9 + wp.x * 0.6) * 0.03 * gust;
    } else if (plantTop > 0.5) {
        pos.x += (sin(s * 2.3 + wp.x * 0.8 + wp.z * 0.4) + 0.4 * sin(s * 4.1 + wp.z * 1.7) + 0.2 * flutter) * 0.23 * gust;
        pos.z += (cos(s * 1.9 + wp.z * 0.8 + wp.x * 0.3) + 0.4 * cos(s * 3.6 + wp.x * 1.5) - 0.2 * flutter) * 0.23 * gust;
    }
    waterMask = 0.0;
    // water = alpha 180 (179 after filtering) AND a biome tint of any colour. Only untinted (grey) textures share
    // that alpha (nether portal, slime, Redstone Tweaks' anchor), so swamp/mangrove/sulfur water counts too
    float cMax = max(Color.r, max(Color.g, Color.b));
    float tinted = (cMax - min(Color.r, min(Color.g, Color.b))) / max(cMax, 0.001);
    if ((marker == 180.0 || marker == 179.0) && tinted > 0.08) {
        waterMask = 1.0;
        // a long rolling swell plus two crossing smaller waves (the same sum tilts the reflections in terrain.fsh);
        // always below the vanilla surface, so it never pokes through boats, slabs or the shore
        float wave = sin(s * 1.1 + dot(wp.xz, vec2(0.55, 0.25)))
                   + 0.6 * sin(s * 1.7 + dot(wp.xz, vec2(-0.35, 0.9)))
                   + 0.35 * sin(s * 2.9 + dot(wp.xz, vec2(1.3, -0.8)));
        pos.y += wave * 0.045 - 0.1;
    }
    viewPos = pos;
    // sun shading input: rgb = daylight colour (lightmap texel with no block light and full sky light),
    // a = how much real sunlight reaches this vertex (full sky light only; shaded spots get the lightmap shadow)
    #ifndef OIT_ALPHA_ONLY
    vec3 daySky = texelFetch(Sampler2, ivec2(0, 15), 0).rgb;
    #else
    vec3 daySky = vec3(1.0);
    #endif
    float dayAmt = smoothstep(0.35, 0.85, dot(daySky, vec3(0.3, 0.5, 0.2)));
    sunLight = vec4(daySky, dayAmt * smoothstep(0.86, 1.0, float(UV2.y) / 240.0));
    lightUV = vec2(UV2);

    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    sphericalVertexDistance = fog_spherical_distance(pos);
    cylindricalVertexDistance = fog_cylindrical_distance(pos);
    #ifndef OIT_ALPHA_ONLY
    vertexColor = Color;   // sky-pack: the light is applied per pixel in terrain.fsh
    #else
    vertexColor = Color;
    #endif
    texCoord0 = UV0;

    const float chunkFullyVisibleRange = 16.0;
    float dist = length(pos);
    chunkVisibility = mix(1.0, ChunkVisibility, clamp((dist - chunkFullyVisibleRange) / chunkFullyVisibleRange, 0.0, 1.0));
}
