#version 330
#extension GL_ARB_separate_shader_objects : require

#include <sodium:globals.glsl>
#include <sodium:fog.glsl>
#include <sodium:chunk_vertex.glsl>

layout(location = 0) out vec4 v_Color;
layout(location = 1) out vec2 v_TexCoord;

// sky-pack: our terrain effects for Sodium (see sky_sodium.py in the server's resourcepack-src)
layout(location = 4) out float v_WaterMask;
layout(location = 5) out vec3 v_ViewPos;
layout(location = 6) out vec4 v_SunLight;
layout(location = 7) out vec2 v_LightCoord;
layout(location = 8) out vec3 v_RegionPos;
layout(location = 9) out float v_Time;
uniform sampler2D u_BlockTex;  // declared like Sodium's own u_LightTex (works on both backends)
const float B = 0.04908739;    // 2*pi/128: x/z patterns repeat every region (128 blocks)
const float BY = 0.09817477;   // 2*pi/64:  y patterns repeat every region (64 blocks)

#ifdef USE_FOG
layout(location = 2) out vec2 v_FragDistance;
layout(location = 3) out float fadeFactor;
#endif

uniform isamplerBuffer u_SectionTimeInfo;

#ifdef VULKAN
layout(push_constant) uniform PC {
    vec3 u_RegionOffset;
    int u_CurrentTime;
    uint u_RegionID;
};
#else
uniform vec3 u_RegionOffset;
uniform int u_CurrentTime;
uniform uint u_RegionID;
#endif

#ifndef OIT_ALPHA_ONLY
uniform sampler2D u_LightTex; // The light map texture sampler
#endif

uvec3 _get_relative_chunk_coord(uint pos) {
    // Packing scheme is defined by LocalSectionIndex
    return uvec3(pos) >> uvec3(5u, 0u, 2u) & uvec3(7u, 3u, 7u);
}

vec3 _get_draw_translation(uint pos) {
    return _get_relative_chunk_coord(pos) * vec3(16.0);
}

void main() {
    _vert_init();

    // Transform the chunk-local vertex position into world model space
    vec3 translation = u_RegionOffset + _get_draw_translation(_draw_id);
    vec3 position = _vert_position + translation;

    // sky-pack: wind and waves. wp = position inside this render region (fixed to the world); s = seconds
    vec3 wp = _vert_position + _get_draw_translation(_draw_id);
    float s = float(u_CurrentTime) * 0.001;
    float marker = 0.0;
    float leaf = 0.0;
    float hang = 0.0;
    float plantTop = 0.0;
    // marked sprites carry the marker in a ring just outside the art: check the 4 texels around this vertex's UV
    vec2 uvPx = _vert_tex_diffuse_coord / u_TexelSize;
    // Sodium's fluid quads use the sprite's exact edge UVs (vanilla's sit inside), so read the water marker half a
    // texel inward - the bias says which way is inside the sprite at this corner
    marker = floor(texelFetch(u_BlockTex, ivec2(floor(uvPx + _vert_tex_diffuse_coord_bias * 0.5)), 0).a * 255.0 + 0.5);
    for (int i = 0; i < 4; i++) {
        vec2 o = vec2((i & 1) == 0 ? -0.5 : 0.5, (i & 2) == 0 ? -0.5 : 0.5);
        float a = floor(texelFetch(u_BlockTex, ivec2(floor(uvPx + o)), 0).a * 255.0 + 0.5);
        if (a == 253.0) leaf = 1.0;
        if (a == 252.0) hang = 1.0;
        if (a == 251.0) plantTop = 1.0;
    }
    // gusts roll across the land; a fast flutter rides on the slow sway
    float gust = 0.55 + 0.45 * sin(s * 0.31 + wp.x * B + wp.z * B);
    float flutter = sin(s * 7.3 + wp.x * (47.0 * B) + wp.z * (39.0 * B) + wp.y * (17.0 * BY));
    if (leaf > 0.5) {
        position.x += (sin(s * 1.9 + wp.x * (14.0 * B) + wp.y * (4.0 * BY)) + 0.5 * sin(s * 3.7 + wp.z * (26.0 * B)) + 0.3 * flutter) * 0.13 * gust;
        position.z += (cos(s * 1.6 + wp.z * (14.0 * B) + wp.y * (3.0 * BY)) + 0.5 * cos(s * 3.1 + wp.x * (22.0 * B)) - 0.3 * flutter) * 0.13 * gust;
        position.y += (sin(s * 2.6 + wp.x * (18.0 * B) + wp.z * (18.0 * B)) + 0.4 * flutter) * 0.05 * gust;
    } else if (hang > 0.5) {
        // vines: the whole sheet lifts and drifts; small sideways part so it never sinks into its wall
        position.y += (sin(s * 2.1 + wp.x * (16.0 * B) + wp.z * (16.0 * B) + wp.y * (5.0 * BY)) + 0.3 * flutter) * 0.07 * gust;
        position.x += sin(s * 1.7 + wp.y * (9.0 * BY) + wp.z * (12.0 * B)) * 0.03 * gust;
        position.z += cos(s * 1.5 + wp.y * (9.0 * BY) + wp.x * (12.0 * B)) * 0.03 * gust;
    } else if (plantTop > 0.5) {
        position.x += (sin(s * 2.3 + wp.x * (16.0 * B) + wp.z * (8.0 * B)) + 0.4 * sin(s * 4.1 + wp.z * (35.0 * B)) + 0.2 * flutter) * 0.23 * gust;
        position.z += (cos(s * 1.9 + wp.z * (16.0 * B) + wp.x * (6.0 * B)) + 0.4 * cos(s * 3.6 + wp.x * (31.0 * B)) - 0.2 * flutter) * 0.23 * gust;
    }
    // water = alpha 180 (179 after filtering) AND a biome tint of any colour (only untinted textures share that alpha)
    v_WaterMask = 0.0;
    float cMax = max(_vert_color.r, max(_vert_color.g, _vert_color.b));
    float tinted = (cMax - min(_vert_color.r, min(_vert_color.g, _vert_color.b))) / max(cMax, 0.001);
    if ((marker == 180.0 || marker == 179.0) && tinted > 0.08) {
        v_WaterMask = 1.0;
        // rolling swell, always below the vanilla surface; flat within 8 blocks of a region border
        float edge = min(min(wp.x, 128.0 - wp.x), min(wp.z, 128.0 - wp.z));
        float wave = sin(s * 1.1 + dot(wp.xz, vec2(11.0, 5.0) * B))
                   + 0.6 * sin(s * 1.7 + dot(wp.xz, vec2(-7.0, 18.0) * B))
                   + 0.35 * sin(s * 2.9 + dot(wp.xz, vec2(26.0, -16.0) * B));
        position.y += wave * 0.045 * smoothstep(0.0, 8.0, edge) - 0.1;
    }
    v_ViewPos = position;
    v_RegionPos = wp;
    v_Time = s;

#ifdef USE_FOG
    v_FragDistance = getFragDistance(position);

    int chunkId = int(_draw_id);
    int chunkFade = texelFetch(u_SectionTimeInfo, int((u_RegionID * 256u) + uint(chunkId))).r;
    int fadeTime = u_CurrentTime - chunkFade;
    float elapsed = float(fadeTime);
    float fade = clamp(float(u_CurrentTime - chunkFade) * u_FadePeriodInv, 0.0, 1.0);
    fadeFactor = (chunkFade < 0) ? 1.0 : fade;
#endif

    // Transform the vertex position into model-view-projection space
    gl_Position = u_ProjectionMatrix * u_ModelViewMatrix * vec4(position, 1.0);

    // Add the light color to the vertex color, and pass the texture coordinates to the fragment shader
    // sky-pack: the light is applied per pixel in the fragment shader (round, soft light pools)
    v_Color = _vert_color;
    v_LightCoord = _vert_tex_light_coord;
    // sunlit shading input: rgb = daylight colour (light map with no block light, full sky light),
    // a = how much real sunlight reaches this vertex (full sky light only)
#ifndef OIT_ALPHA_ONLY
    vec3 daySky = texelFetch(u_LightTex, ivec2(0, 15), 0).rgb;
#else
    vec3 daySky = vec3(1.0);
#endif
    float dayAmt = smoothstep(0.35, 0.85, dot(daySky, vec3(0.3, 0.5, 0.2)));
    v_SunLight = vec4(daySky, dayAmt * smoothstep(0.86, 1.0, (_vert_tex_light_coord.y * 16.0 - 0.5) / 15.0));

    v_TexCoord = (_vert_tex_diffuse_coord_bias * u_TexCoordShrink) + _vert_tex_diffuse_coord; // FMA for precision
}
