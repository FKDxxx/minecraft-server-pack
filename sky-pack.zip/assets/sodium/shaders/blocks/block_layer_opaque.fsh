#version 460 core

#include <sodium:globals.glsl>
#include <sodium:fog.glsl>
#include <sodium:chunk_material.glsl>
#include <minecraft:oit.glsl>

layout(location = 0) in vec4 v_Color; // The interpolated vertex color
layout(location = 1) in vec2 v_TexCoord; // The interpolated block texture coordinates
layout(location = 2) in vec2 v_FragDistance; // The fragment's distance from the camera (cylindrical and spherical)
layout(location = 3) in float fadeFactor;

// sky-pack: our terrain effects for Sodium (see sky_sodium.py in the server's resourcepack-src)
layout(location = 4) in float v_WaterMask;
layout(location = 5) in vec3 v_ViewPos;
layout(location = 6) in vec4 v_SunLight;
layout(location = 7) in vec2 v_LightCoord;
layout(location = 8) in vec3 v_RegionPos;
layout(location = 9) in float v_Time;
#ifndef OIT_ALPHA_ONLY
uniform sampler2D u_LightTex;
#endif
const float B = 0.04908739;    // 2*pi/128: patterns repeat every render region

uniform sampler2D u_BlockTex; // The block texture

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor; // The output fragment for the color framebuffer
#endif

vec4 calculateFinalColor(vec4 color) {
    #ifdef OIT_ACCUMULATE
        color = sampleColorForAccumulation(color);
        vec4 fogColor = vec4(u_FogColor.rgb * color.a, u_FogColor.a);
    #else
        vec4 fogColor = u_FogColor;
    #endif

    #ifdef OIT_ALPHA_ONLY
    float factor = 1.0;
    #else
    float factor = fadeFactor;
    #endif

    return _linearFog(color, v_FragDistance, fogColor, u_EnvironmentFog, u_RenderFog, factor);
}
vec4 sampleNearest(sampler2D source, vec2 uv, vec2 pixelSize, vec2 du, vec2 dv, vec2 texelScreenSize) {
    // Convert our UV back up to texel coordinates and find out how far over we are from the center of each pixel
    vec2 uvTexelCoords = uv / pixelSize;
    vec2 texelCenter = round(uvTexelCoords) - 0.5f;
    vec2 texelOffset = uvTexelCoords - texelCenter;

    // Move our offset closer to the texel center based on texel size on screen
    texelOffset = (texelOffset - 0.5f) * pixelSize / texelScreenSize + 0.5f;
    texelOffset = clamp(texelOffset, 0.0f, 1.0f);

    uv = (texelCenter + texelOffset) * pixelSize;
    return textureGrad(source, uv, du, dv);
}

vec4 sampleNearest(sampler2D source, vec2 uv, vec2 pixelSize) {
    vec2 du = dFdx(uv);
    vec2 dv = dFdy(uv);
    vec2 texelScreenSize = sqrt(du * du + dv * dv);
    return sampleNearest(source, uv, pixelSize, du, dv, texelScreenSize);
}

// Rotated Grid Super-Sampling
vec4 sampleRGSS(sampler2D source, vec2 uv, vec2 pixelSize) {
    vec2 du = dFdx(uv);
    vec2 dv = dFdy(uv);

    vec2 texelScreenSize = sqrt(du * du + dv * dv);
    float maxTexelSize = max(texelScreenSize.x, texelScreenSize.y);

    float minPixelSize = min(pixelSize.x, pixelSize.y);

    float transitionStart = minPixelSize * 1.0;
    float transitionEnd = minPixelSize * 2.0;
    float blendFactor = smoothstep(transitionStart, transitionEnd, maxTexelSize);

    float duLength = length(du);
    float dvLength = length(dv);
    float minDerivative = min(duLength, dvLength);
    float maxDerivative = max(duLength, dvLength);

    float effectiveDerivative = sqrt(minDerivative * maxDerivative);

    float mipLevelExact = max(0.0, log2(effectiveDerivative / minPixelSize));

    const vec2 offsets[4] = vec2[](
    vec2(0.125, 0.375),
    vec2(-0.125, -0.375),
    vec2(0.375, -0.125),
    vec2(-0.375, 0.125)
    );

    vec4 rgssColor = vec4(0.0);
    for (int i = 0; i < 4; ++i) {
        vec2 sampleUV = uv + offsets[i] * pixelSize;
        rgssColor += textureLod(source, sampleUV, mipLevelExact);
    }
    rgssColor *= 0.25;

    vec4 nearestColor = sampleNearest(source, uv, pixelSize, du, dv, texelScreenSize);

    return mix(nearestColor, rgssColor, blendFactor);
}

void main() {
    vec4 color = u_UseRGSS ? sampleRGSS(u_BlockTex, v_TexCoord, u_TexelSize) : sampleNearest(u_BlockTex, v_TexCoord, u_TexelSize);
    color *= v_Color; // Apply per-vertex color modulator

    #ifndef OIT_ALPHA_ONLY
    // sky-pack: per-pixel light - the light LEVEL is blended across the face first and only then turned into
    // brightness, so torch light falls off in round, soft pools instead of straight corner ramps
    vec2 lt = clamp(v_LightCoord * 16.0 - 0.5, 0.0, 15.0);
    ivec2 l0 = ivec2(floor(lt));
    ivec2 l1 = min(l0 + 1, ivec2(15));
    vec2 lf = lt - vec2(l0);
    vec3 lm = mix(mix(texelFetch(u_LightTex, l0, 0).rgb, texelFetch(u_LightTex, ivec2(l1.x, l0.y), 0).rgb, lf.x),
                  mix(texelFetch(u_LightTex, ivec2(l0.x, l1.y), 0).rgb, texelFetch(u_LightTex, l1, 0).rgb, lf.x), lf.y);
    color.rgb *= lm;
    #endif
    vec3 geo = normalize(cross(dFdx(v_ViewPos), dFdy(v_ViewPos)));
    #ifndef OIT_ALPHA_ONLY
    if (v_WaterMask < 0.5 && v_SunLight.a > 0.01) {
        // sky-pack: sunlit shading - only where full sunlight reaches, faces turned to the sun's path catch warm
        // light (tops most, then east/west) and faces turned away cool slightly; warmer at dusk
        float lit = max(geo.y, 0.0) * 0.7 + abs(geo.x) * 0.45 + abs(geo.z) * 0.15;
        float k = clamp((lit - 0.35) / 0.35, -1.0, 1.0);
        float dusk = clamp((v_SunLight.r - v_SunLight.b) * 3.0, 0.0, 1.0);
        vec3 warm = mix(vec3(1.10, 1.03, 0.90), vec3(1.16, 0.99, 0.82), dusk);
        vec3 cool = vec3(0.88, 0.93, 1.03);
        vec3 tint = k > 0.0 ? mix(vec3(1.0), warm, k) : mix(vec3(1.0), cool, -k);
        color.rgb *= mix(vec3(1.0), tint, v_SunLight.a);
    }
    #endif
    if (v_WaterMask > 0.5) {
        // sky-pack: water surfaces reflect the sky (fresnel), with moving ripples and sparkles; calm near region
        // borders (two regions' clocks meet there)
        vec3 dir = normalize(v_ViewPos);
        float level = smoothstep(0.80, 0.95, abs(geo.y));
        if (dir.y < 0.0 && level > 0.0) {
            vec2 w = v_RegionPos.xz;
            float t = v_Time;
            float calm = smoothstep(0.0, 8.0, min(min(w.x, 128.0 - w.x), min(w.y, 128.0 - w.y)));
            vec2 g = vec2(0.8, 0.6) * cos(dot(w, vec2(37.0, 28.0) * B) + t * 1.7) * 0.07
                   + vec2(-0.5, 0.86) * cos(dot(w, vec2(-40.0, 68.0) * B) + t * 2.3) * 0.045
                   + vec2(0.2, -0.98) * cos(dot(w, vec2(29.0, -142.0) * B) + t * 3.1) * 0.03;
            // tilt with the vertex swell (same sum as the vertex shader) so reflections roll with it
            g += (vec2(0.55, 0.25) * cos(t * 1.1 + dot(w, vec2(11.0, 5.0) * B))
                + 0.6 * vec2(-0.35, 0.9) * cos(t * 1.7 + dot(w, vec2(-7.0, 18.0) * B))
                + 0.35 * vec2(1.3, -0.8) * cos(t * 2.9 + dot(w, vec2(26.0, -16.0) * B))) * 0.045 * 2.5;
            g *= calm;
            float crest = sin(t * 1.1 + dot(w, vec2(11.0, 5.0) * B))
                        + 0.6 * sin(t * 1.7 + dot(w, vec2(-7.0, 18.0) * B))
                        + 0.35 * sin(t * 2.9 + dot(w, vec2(26.0, -16.0) * B));
            vec3 n = normalize(vec3(-g.x, 1.0, -g.y));
            vec3 r = reflect(dir, n);
            float up = clamp(r.y, 0.0, 1.0);
            vec3 horizon = u_FogColor.rgb * 1.08;
            vec3 zenith = u_FogColor.rgb * vec3(0.52, 0.66, 0.96);
            vec3 skyRefl = mix(horizon, zenith, pow(up, 0.6));
            float cosi = clamp(-dot(dir, n), 0.0, 1.0);
            float fresnel = clamp(0.02 + 0.98 * pow(1.0 - cosi, 5.0), 0.0, 0.85) * level;
            float day = clamp(dot(u_FogColor.rgb, vec3(0.3, 0.5, 0.2)) * 1.6, 0.0, 1.0);
            float spark = pow(max(0.0, sin(w.x * (96.0 * B) + t * 2.9) * sin(w.y * (108.0 * B) - t * 2.3)), 60.0)
                        * smoothstep(0.55, 0.95, 1.0 - cosi) * day * level * calm;
            #ifndef OIT_ALPHA_ONLY
            color.rgb = mix(color.rgb, skyRefl, fresnel) + spark * 0.18;
            color.rgb *= 1.0 + max(crest, 0.0) * 0.05 * calm;   // crests catch a little more light
            #endif
            color.a = mix(color.a, 1.0, fresnel * 0.6);
        }
    }

#ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
#endif

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = calculateFinalColor(color);
    #endif
}
